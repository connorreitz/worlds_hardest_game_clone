#include "gba.h"
#include "game.h"
#include <stdio.h>
#include <stdlib.h>

void movement(Enemy* e);
