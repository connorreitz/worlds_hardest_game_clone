/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 difficulty_meter difficulty_meter.png 
 * Time-stamp: Friday 04/03/2020, 02:27:13
 * 
 * Image Information
 * -----------------
 * difficulty_meter.png 80@27
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DIFFICULTY_METER_H
#define DIFFICULTY_METER_H

extern const unsigned short difficulty_meter[2160];
#define DIFFICULTY_METER_SIZE 4320
#define DIFFICULTY_METER_LENGTH 2160
#define DIFFICULTY_METER_WIDTH 80
#define DIFFICULTY_METER_HEIGHT 27

#endif

