/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 win_screen win_screen.png 
 * Time-stamp: Friday 04/03/2020, 02:26:41
 * 
 * Image Information
 * -----------------
 * win_screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_SCREEN_H
#define WIN_SCREEN_H

extern const unsigned short win_screen[38400];
#define WIN_SCREEN_SIZE 76800
#define WIN_SCREEN_LENGTH 38400
#define WIN_SCREEN_WIDTH 240
#define WIN_SCREEN_HEIGHT 160

#endif

