#include "gba.h"
#include "game.h"
#include <stdio.h>
#include <stdlib.h>

void moveUp(Player* p);
void moveDown(Player* p);
void moveLeft(Player* p);
void moveRight(Player* p);

