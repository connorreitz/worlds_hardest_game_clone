------ WORLD'S HARDEST GAME CLONE -------
this gba game is a replica of the world's
hardest game. to play, use the arrows to move
the red block out of the start zone and into the
other green zone (end zone). if you hit one of
the enemies (moving blue squares), you have
one more attempt before you lose. button input
is restricted so you cannot move diagonally,
just up/down and left/right at once.
