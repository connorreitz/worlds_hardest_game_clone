#include "game.h"

#include <stdio.h>
#include <stdlib.h>

#include "gba.h"

#define HORIZONTAL 1

void setup(Player* p, Enemy* e1, Enemy* e2, Enemy* e3);
